<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<style>
			
			body {background-image: url("11.jpg"); background-size:cover;background-repeat: no-repeat;}
	</style>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
	<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<title>Student information</title>
<link rel="stylesheet" type="text/css" href="style.css" />
	<link rel="stylesheet" href="lightbox.css" type="text/css" media="screen" />
	
	<script src="js/prototype.js" type="text/javascript"></script>
	<script src="js/scriptaculous.js?load=effects" type="text/javascript"></script>
	<script src="js/lightbox.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/java.js"></script>
    <script>
function showitem(str)
{
	
	if (window.XMLHttpRequest)
	{
		
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("Item").innerHTML=xmlhttp.responseText;
		}
	}
	xmlhttp.open("GET","Item.php?q="+str,true);
	xmlhttp.send();
	
}
</script>
</head>
<body>
<div class="container">
            
		 <div class="row">
                <div class="col-xs-12" >
					
                <h2>Deakin University Lab Entry Check</h2>      
                <p>To develop a mobile app that can be used to check that students entering labs have completed the required safety unit.</p>
						<div id="newCarousel" class="carousel slide" data-ride="carousel">
   
    <ol class="carousel-indicators">
        <li data-target="#newCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#newCarousel" data-slide-to="1"></li>
        <li data-target="#newCarousel" data-slide-to="2"></li>
    </ol>
    <!-- Wrapper for slides -->
    <div class="carousel-inner">
        <div class="item active">
			
            <img src="1.jpg" alt="Deakin Burwood" style="width:400px;height: 300px" align="center">
			<div class="carousel-caption">
            <p> Deakin University </p>
        </div>
        </div>
        <div class="item">
			
            <img src="2.jpg" alt="Deakin" style="width:400px;height: 300px" align="center">
			<div class="carousel-caption">
            <p> Deakin University </p>
        </div>
			
        </div>
        <div class="item">
            <img src="3.jpg" alt="Deakin " style="width:400px;height: 300px" align="center">
			<div class="carousel-caption">
            <p> Deakin University </p>
        </div>
        </div>
    </div>
    <!-- Left and right controls -->
    <a class="left carousel-control" href="#newCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#newCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
            </div>
			 
                
            </div>
		
		
            <div class="row">
                <div class="col-xs-3" >
					
					<div class="btn-group-vertical btn-group-lg" >
						<h2>
  <a href="home.html">Home</a><br><br>
                <a href="index.html" >Lab</a><br><br>
                <a href="http://www.deakin.edu.au/" >Help</a><br><br>
			   
							</h2>
</div>
   
			
					
					
				</div>
                <div class="col-xs-9" >
					<h3>Student information</h3>
					<h2>
					<?php
//database
$q=$_REQUEST['content'];; //or $q=$_REQUEST["q"];

   /* Set oracle user login and password info */
$xmlDoc = new DOMDocument();
$xmlDoc->load("flower.xml");
$x=$xmlDoc->getElementsByTagName('COMMON');
$m=$xmlDoc->getElementsByTagName('search');
$a=0;
for ($i=0; $i<=$m->length-1; $i++)
{
	
	if ($m->item($i)->nodeType==1)
	{
		if (strtolower($m->item($i)->childNodes->item(0)->nodeValue) ==strtolower ($q))
		{
			$n=($m->item($i)->parentNode);
			
		}
	}
}

$flower=($n->childNodes);
for ($i=6;$i<$flower->length;$i++)
{ 
	
	if ($flower->item($i)->nodeType==1)
	{
		if ($flower->item($i)->nodeName!="PHOTO" ){
		echo("<b>" . $flower->item($i)->nodeName . ":</b> ");
		echo($flower->item($i)->childNodes->item(0)->nodeValue);
		echo("<br>");
		$a=$a+1;
		}
	}
}
if($a==0){
echo "there no this student, please return to <a href='home.html '> search </a> <br>";
}

?>
					
			</h2>	
				
				</div>
                
            </div>
        </div>


             
	
                  <!--  A rose is a woody perennial flowering plant of the genus Rosa, in the family Rosaceae, or the flower it bears. There are over a hundred species and thousands of cultivars.<br />
                   Roses have acquired cultural significance in many societies. Rose plants range in size from compact, miniature roses, to climbers that can reach seven meters in height.                    </p>  -->
                    
                    <!--php code  -->
                    <?php
//database
$q=$_REQUEST['content'];; //or $q=$_REQUEST["q"];

   /* Set oracle user login and password info */
$dbuser = "wenbo"; /* your deakin login */
$dbpass = "c3Xa8XZu"; /* your oracle access password */
$db = "SSID";
$connect = oci_connect($dbuser, $dbpass, $db);

if (!$connect) {
echo "An error occurred connecting to the database";
exit;
}

/* build sql statement using form data */
$query = "SELECT * FROM Plants";

/* check the sql statement for errors and if errors report them */
$stmt = oci_parse($connect, $query);
//echo "SQL: $query<br>";
if(!$stmt) {
echo "An error occurred in parsing the sql string.\n";
exit;
}
oci_execute($stmt);




while(oci_fetch_array($stmt)) {
	if(strtolower($q)==strtolower(oci_result($stmt,"COMMON"))){

echo  oci_result($stmt,"PRICE")." $";

	}
}





// Close the connection
oci_close($connect); 

?>
    
<script>

           window.onload=showitem(123);  
				
</script>

</body>
<script type="text/javascript">

var tabber1 = new Yetii({
id: 'demo'
});

</script>
</html>