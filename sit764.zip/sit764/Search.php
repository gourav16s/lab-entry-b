<?php
//database
$q=$_GET["q"]; //or $q=$_REQUEST["q"];

   /* Set oracle user login and password info */
$dbuser = "wenbo"; /* your deakin login */
$dbpass = "c3Xa8XZu"; /* your oracle access password */
$db = "SSID";
$connect = oci_connect($dbuser, $dbpass, $db);

if (!$connect) {
echo "An error occurred connecting to the database";
exit;
}

/* build sql statement using form data */
$query = "SELECT * FROM Plants";

/* check the sql statement for errors and if errors report them */
$stmt = oci_parse($connect, $query);
//echo "SQL: $query<br>";
if(!$stmt) {
echo "An error occurred in parsing the sql string.\n";
exit;
}
oci_execute($stmt);


echo "<table border='1'>
<tr>
<th>Common</th>
<th>Botanical</th>
<th>Zone</th>
<th>Light</th>
<th>Price</th>
<th>Photo</th>
</tr>";

$a=0;
// Display all the values in the retrieved records, one record per row, in a loop
while(oci_fetch_array($stmt)) {
	if(strtolower($q)==strtolower(oci_result($stmt,"COMMON"))){
echo "<tr>";
echo "<td>" . oci_result($stmt,"COMMON") . "</td>";
echo "<td>" . oci_result($stmt,"BOTANICAL") . "</td>";
echo "<td>" . oci_result($stmt,"ZONE") . "</td>";
echo "<td>" . oci_result($stmt,"LIGHT") . "</td>";
echo "<td>" . oci_result($stmt,"PRICE") . "</td>";
echo "<td>" . ("<img src='$q.jpg' width='100' height='100' / >") . "</td>";
echo "</tr>";
$a=$a+1;
	}
}

if($a==0)
{
	echo "<tr>";
echo "<td>" . "no found" . "</td>";
echo "<td>" . "   " . "</td>";
echo "<td>" . "   " . "</td>";
echo "<td>" . "   " . "</td>";
echo "<td>" . "   " . "</td>";
echo "<td>" . "   " . "</td>";
echo "</tr>";
}
echo "</table>";

// Close the connection
oci_close($connect); 







//XML method
/*
$q=$_GET["q"];
$xmlDoc = new DOMDocument();
$xmlDoc->load("flower.xml");
$x=$xmlDoc->getElementsByTagName('COMMON');
$m=$xmlDoc->getElementsByTagName('search');
*/
/*
for ($i=0; $i<=$x->length-1; $i++)
{
	
	if ($x->item($i)->nodeType==1)
	{
		if (strtolower($x->item($i)->childNodes->item(0)->nodeValue) ==strtolower ($q))
		{
			$y=($x->item($i)->parentNode);
		}
	}
}

$flower=($y->childNodes);

for ($i=0;$i<$flower->length;$i++)
{ 
	
	if ($flower->item($i)->nodeType==1)
	{
		echo("<b>" . $flower->item($i)->nodeName . ":</b> ");
		echo($flower->item($i)->childNodes->item(0)->nodeValue);
		echo("<br>");
	}
}
*/
/*
$a=0;
for ($i=0; $i<=$m->length-1; $i++)
{
	
	if ($m->item($i)->nodeType==1)
	{
		if (strtolower($m->item($i)->childNodes->item(0)->nodeValue) ==strtolower ($q))
		{
			$n=($m->item($i)->parentNode);
			
		}
	}
}

$flower=($n->childNodes);
$i=16;
echo"<br>";
echo("<b>" . $flower->item($i)->nodeName . ":</b> ");
		echo($flower->item($i)->childNodes->item(0)->nodeValue);
		echo("<br>");
		*/
/*
for ($i=6;$i<$flower->length;$i++)
{ 
	
	if ($flower->item($i)->nodeType==1)
	{
		echo("<b>" . $flower->item($i)->nodeName . ":</b> ");
		echo($flower->item($i)->childNodes->item(0)->nodeValue);
		echo("<br>");
		$a=$a+1;
	}
}
if($a>1)
{
echo ("<img src='$q.jpg' width='400' height='400' / >");
}
*/

?>