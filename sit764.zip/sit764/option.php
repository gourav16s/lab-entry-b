<?php

   /* Set oracle user login and password info */
$dbuser = "wenbo"; /* your deakin login */
$dbpass = "c3Xa8XZu"; /* your oracle access password */
$db = "SSID";
$connect = oci_connect($dbuser, $dbpass, $db);

if (!$connect) {
echo "An error occurred connecting to the database";
exit;
}

/* build sql statement using form data */
$query = "SELECT * FROM Plants";

/* check the sql statement for errors and if errors report them */
$stmt = oci_parse($connect, $query);
//echo "SQL: $query<br>";
if(!$stmt) {
echo "An error occurred in parsing the sql string.\n";
exit;
}
oci_execute($stmt);

    
	while(oci_fetch_array($stmt)) {
	$fg1 = oci_result($stmt,"COMMON");
	echo "<option value=";
	echo "\"";
	echo $fgl;
	echo "\" ";
	echo " selected='selected' ";
	echo ">";
	echo "<a href='details.php'>";
	echo $fg1;
	echo "</a>";
	}
oci_close($connect); 
//$x="rosa";
//echo "<option value=".$x.">";
?>